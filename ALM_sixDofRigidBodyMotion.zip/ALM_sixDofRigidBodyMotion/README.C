// 标注：
// 需要再与run统一等级下编译foamMooring
foamMooring    ./Allwmake

// 然后再编译
ChenfloatingsixDoFRigidBodyMotion3  wmake

// 最后编译
floatingTurbinesFoam

